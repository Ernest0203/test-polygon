# koa-postgres-cra

## Install

```bash
npm run install-all
```

## Start

```bash
npm run dev
```